using System;
using System.Collections.Generic;
using System.Text;

public static class TrascrizioneRNA
{
    public static string ToRna(string dna)

    {
        char G;
        char A;
        char C;
        char T;
        char U;
        string f1DNA;
        string f1RNA;

        if (G)
        {
            
        }

        if( String.IsNullOrEmpty( dna ) )
            return "";
        
        return dna;
    }
}